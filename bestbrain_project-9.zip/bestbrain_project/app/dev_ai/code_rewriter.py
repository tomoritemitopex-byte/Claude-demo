class CodeRewriter: pass
