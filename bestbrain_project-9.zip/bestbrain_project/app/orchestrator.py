class BestBrain: pass
